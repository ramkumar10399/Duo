import 'package:flutter/material.dart';

class LoginTextField extends StatelessWidget {
  String hintText;
  BuildContext context;
  TextEditingController controller;
  late bool obscure;
  late FormFieldValidator<String> validator;
  late TextInputType keyboardType;
  late int maxLength;
  late TextInputAction textInputAction;
  late FocusNode focusNode;
  late FocusNode nextFocus;

  LoginTextField.loginVal(
    this.context,
    this.hintText,
    this.controller,
  );

  LoginTextField.loginObscure(
      this.context, this.hintText, this.controller, this.obscure);

  LoginTextField(
    this.context,
    this.hintText, {
    required this.controller,
    this.obscure = false,
    required this.validator,
    required this.keyboardType,
    required this.maxLength,
    required this.textInputAction,
    required this.focusNode,
    required this.nextFocus,
  });
  @override
  Widget build(BuildContext context) => Theme(
        data: Theme.of(context).copyWith(splashColor: Colors.transparent),
        child: TextFormField(
          controller: controller,
          obscureText: obscure,
          validator: validator,
          keyboardType: keyboardType,
          maxLength: maxLength,
          style: const TextStyle(fontSize: 22, color: Color(0xFFbdc6cf)),
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.grey.shade200,
            hintText: hintText,
            contentPadding: const EdgeInsets.only(left: 14, bottom: 8, top: 8),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white),
              borderRadius: BorderRadius.circular(8),
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white),
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
      );
}
