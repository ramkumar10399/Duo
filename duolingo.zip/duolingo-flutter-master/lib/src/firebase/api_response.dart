class ApiResponse<T> {
  late bool ok;
  String? message;
  T? result;

  ApiResponse.okay() {
    ok = true;
  }

  ApiResponse.ok({required this.result, required this.message}) {
    ok = true;
  }

  ApiResponse.error({required this.result, required this.message}) {
    ok = false;
  }
}
