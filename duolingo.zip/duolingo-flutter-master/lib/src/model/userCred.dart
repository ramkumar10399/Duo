import 'dart:convert' as convert;
import 'package:duolingo/src/sql/prefs.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

class UserCred {
  String? login;
  String? name;
  String? email;
  String? urlPhoto;
  String? token;
  List<String>? roles;

  UserCred.userVal();
  UserCred(
      {required this.login,
      required this.name,
      required this.email,
      required this.urlPhoto,
      required this.token,
      required this.roles});

  UserCred.firebase(
      {required this.login,
      required this.name,
      required this.email,
      required this.urlPhoto,
      required this.token,
      required this.roles});

  UserCred.fromJson(Map<String, dynamic> json) {
    login = json['login'];
    name = json['name'];
    email = json['email'];
    urlPhoto = json['urlPhoto'];
    token = json['token'];
    roles = json['roles'] != null ? json['roles'].cast<String>() : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['login'] = login;
    data['name'] = name;
    data['email'] = email;
    data['urlPhoto'] = urlPhoto;
    data['token'] = token;
    data['roles'] = roles;
    return data;
  }

  static void clear() {
    Prefs.setString("user.prefs", "");
  }

  void save() {
    final Map map = toJson();

    final String json = convert.json.encode(map);

    Prefs.setString("user.prefs", json);
  }

  static Future<UserCred> get() async {
    final String json = await Prefs.getString("user.prefs");
    if (json.isEmpty) {
      return UserCred.userVal();
    }
    Map<String, dynamic> map = convert.json.decode(json);
    final UserCred user = UserCred.fromJson(map);
    return user;
  }

  @override
  String toString() => "";
}
